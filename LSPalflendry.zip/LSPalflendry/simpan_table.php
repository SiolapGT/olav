<?php 

session_start();
$nomor_meja  = $_POST['nomor_meja'];
$status_meja	  = $_POST['status_meja'];

include'koneksi.php';
$sql = "INSERT INTO tbl_meja(nomor_meja,status_meja) VALUES('$nomor_meja','$status_meja')";
$query = mysqli_query($koneksi, $sql);

if($query){ ?>
		<script>
			alert("Data meja Sudah Tersimpan.");
			window.location.assign("entri-meja.php");
		</script>
<?php 
 
}else{ ?>
		<script>
			alert("Data meja Tidak Tersimpan.");
			window.location.assign("entri-meja.php");
		</script>
<?php 

}