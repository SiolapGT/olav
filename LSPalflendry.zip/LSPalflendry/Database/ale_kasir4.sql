-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 24 Mar 2024 pada 22.20
-- Versi server: 10.4.27-MariaDB
-- Versi PHP: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ale_kasir4`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_jenis_menu`
--

CREATE TABLE `tbl_jenis_menu` (
  `id_jenis_menu` int(11) NOT NULL,
  `jenis_menu` varchar(200) NOT NULL,
  `id_pegawai` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tbl_jenis_menu`
--

INSERT INTO `tbl_jenis_menu` (`id_jenis_menu`, `jenis_menu`, `id_pegawai`) VALUES
(40, 'Makanan', 1),
(41, 'Minuman', 1),
(42, 'Paket Hemat 1', 1);

--
-- Trigger `tbl_jenis_menu`
--
DELIMITER $$
CREATE TRIGGER `tJenisMenuDelete` BEFORE DELETE ON `tbl_jenis_menu` FOR EACH ROW BEGIN
 DECLARE nm_peg VARCHAR(100);
 DECLARE jbt VARCHAR(100);
 SELECT nama_pegawai, jabatan INTO nm_peg, jbt FROM tbl_pegawai WHERE id_pegawai = old.id_pegawai;
 INSERT INTO tbl_log(id_pegawai, nama_pegawai, jabatan, aksi) VALUES (old.id_pegawai, nm_peg, jbt, CONCAT('Jenis menu - Menghapus nama pegawai : ', old.jenis_menu ));
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `tJenisMenuTambah` AFTER INSERT ON `tbl_jenis_menu` FOR EACH ROW BEGIN
 DECLARE nm_peg VARCHAR(100);
 DECLARE jbt VARCHAR(100);
 SELECT nama_pegawai, jabatan INTO nm_peg, jbt FROM tbl_pegawai WHERE id_pegawai = new.id_pegawai;
 INSERT INTO tbl_log(id_pegawai, nama_pegawai, jabatan, aksi) VALUES (new.id_pegawai, nm_peg, jbt, CONCAT('Jenis menu - menanbah jenis menu : ', new.jenis_menu));
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `tJenisMenuUpdate` BEFORE UPDATE ON `tbl_jenis_menu` FOR EACH ROW BEGIN
 DECLARE nm_peg VARCHAR(100);
 DECLARE jbt VARCHAR(100);
 SELECT nama_pegawai, jabatan INTO nm_peg, jbt FROM tbl_pegawai WHERE id_pegawai = old.id_pegawai;
 INSERT INTO tbl_log(id_pegawai, nama_pegawai, jabatan, aksi) VALUES (old.id_pegawai, nm_peg, jbt, CONCAT('Jenis menu - mengubah jenis menu : ', old.jenis_menu, ' menjadi ', new.jenis_menu));
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_log`
--

CREATE TABLE `tbl_log` (
  `id_log` int(11) NOT NULL,
  `id_pegawai` int(11) NOT NULL,
  `nama_pegawai` varchar(100) DEFAULT NULL,
  `jabatan` varchar(100) DEFAULT NULL,
  `aksi` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tbl_log`
--

INSERT INTO `tbl_log` (`id_log`, `id_pegawai`, `nama_pegawai`, `jabatan`, `aksi`, `date`) VALUES
(648, 2, 'Administrator', 'Admin', 'Login : merubah username : manajer menjadi Owner', '2024-03-24 15:44:50'),
(649, 1, 'Manager Baru', 'Manajer', 'Pegawai - Mengubah nama pegawai : Manager Baru menjadi Owner, jenis kelamin : Perempuan menjadi Perempuan, alamat : Jl. Jakarta menjadi Jl. Jakarta, telp : 081 menjadi 081', '2024-03-24 15:45:16'),
(650, 2, 'Administrator', 'Admin', 'Login : merubah username : Owner menjadi Owner', '2024-03-24 15:47:54'),
(651, 19, NULL, NULL, 'Pegawai - menanbah nama pegawai : pantat dan jabatan sebagai Kasir', '2024-03-24 16:23:29'),
(652, 20, 'Owner', 'Manajer', 'Pegawai - menanbah nama pegawai : pantat2 dan jabatan sebagai Admin', '2024-03-24 16:24:08'),
(653, 1, 'Owner', 'Manajer', 'Nama menu - mengubah nama menu : Nasi Liwet menjadi Nasi Liwet, jenis menu : Makanan menjadi Makanan dan harga dari Rp. 25000 menjadi Rp. 30000', '2024-03-24 18:01:45'),
(654, 21, 'Owner', 'Manajer', 'Pegawai - menanbah nama pegawai : Waiter dan jabatan sebagai Waiter', '2024-03-24 18:36:23'),
(655, 1, 'Owner', 'Manajer', 'Login : menambahkan username : Waiter', '2024-03-24 18:37:17'),
(656, 0, 'Owner', 'Manajer', 'Login : menghapus username Waiter', '2024-03-24 18:37:27'),
(657, 2, 'Administrator', 'Admin', 'Login : menambahkan username : Waiter', '2024-03-24 18:37:57'),
(658, 21, 'Owner', 'Manajer', 'Pegawai - Mengubah nama pegawai : Waiter menjadi Waiter, jenis kelamin : Perempuan menjadi Perempuan, alamat : MERICAAAAAAAAAAAAAAAAAAAAAAAAAAA menjadi MERICAAAAAAAAAAAAAAAAAAAAAAAAAAA, telp : 021 menjadi 021', '2024-03-24 18:49:56'),
(659, 18, 'Edi Kribo', 'Kasir', 'Transaksi detail - menjual Es Jeruk sebanyak 1 dengan harga Rp. 10000', '2024-03-24 18:58:42'),
(660, 1, 'Owner', 'Manajer', 'Nama menu - Menghapus nama menu : Tahu + Tempe ', '2024-03-24 19:08:53'),
(661, 19, NULL, NULL, 'Pegawai - Menghapus nama pegawai : pantat', '2024-03-24 20:04:48'),
(662, 20, 'Owner', 'Manajer', 'Pegawai - Menghapus nama pegawai : pantat2', '2024-03-24 20:04:50'),
(663, 18, 'Owner', 'Manajer', 'Pegawai - Mengubah nama pegawai : Edi Kribo menjadi Vino, jenis kelamin : Laki-laki menjadi Laki-laki, alamat : Jl. Sunda No. 1 menjadi Jl. Sunda No. 1, telp : 081234 menjadi 081234', '2024-03-24 20:07:22'),
(664, 10, 'Waiter', 'Waiter', 'Pegawai - Mengubah nama pegawai : Waiter menjadi Frieren, jenis kelamin : Perempuan menjadi Perempuan, alamat : MERICAAAAAAAAAAAAAAAAAAAAAAAAAAA menjadi MERICAAAAAAAAAAAAAAAAAAAAAAAAAAA, telp : 021 menjadi 021', '2024-03-24 20:10:20'),
(665, 2, 'Owner', 'Manajer', 'Pegawai - Mengubah nama pegawai : Administrator menjadi Aji, jenis kelamin : Laki-laki menjadi Laki-laki, alamat : Jl. Subang menjadi Jl. Subang, telp : 081 menjadi 081', '2024-03-24 20:10:55'),
(666, 1, 'Owner', 'Manajer', 'Pegawai - Mengubah nama pegawai : Owner menjadi Haikal, jenis kelamin : Perempuan menjadi Perempuan, alamat : Jl. Jakarta menjadi Jl. Jakarta, telp : 081 menjadi 081', '2024-03-24 20:11:06'),
(667, 1, 'Haikal', '', 'Pegawai - Mengubah nama pegawai : Haikal menjadi Manager, jenis kelamin : Perempuan menjadi Perempuan, alamat : Jl. Jakarta menjadi Jl. Jakarta, telp : 081 menjadi 081', '2024-03-24 20:36:54'),
(668, 1, 'Manager', '', 'Pegawai - Mengubah nama pegawai : Manager menjadi Haikal, jenis kelamin : Perempuan menjadi Perempuan, alamat : Jl. Jakarta menjadi Jl. Jakarta, telp : 081 menjadi 081', '2024-03-24 20:38:59'),
(669, 1, 'Haikal', '', 'Pegawai - Mengubah nama pegawai : Haikal menjadi Haikal, jenis kelamin : Perempuan menjadi Perempuan, alamat : Jl. Jakarta menjadi Jl. Jakarta, telp : 081 menjadi 081', '2024-03-24 20:53:23');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_login`
--

CREATE TABLE `tbl_login` (
  `id_login` int(11) NOT NULL,
  `id_pegawai` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `id_admin` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tbl_login`
--

INSERT INTO `tbl_login` (`id_login`, `id_pegawai`, `username`, `password`, `id_admin`) VALUES
(10, 10, 'Waiter', '202cb962ac59075b964b07152d234b70', 2),
(93, 1, 'Owner', '202cb962ac59075b964b07152d234b70', 2),
(94, 2, 'admin', '21232f297a57a5a743894a0e4a801fc3', 2),
(113, 18, 'kasir', 'c7911af3adbd12a035b289556d96470a', 2),
(114, 17, 'kasir1', '29c748d4d8f4bd5cbc0f3f60cb7ed3d0', 2);

--
-- Trigger `tbl_login`
--
DELIMITER $$
CREATE TRIGGER `tLoginHapus` BEFORE DELETE ON `tbl_login` FOR EACH ROW BEGIN
 DECLARE nm_peg VARCHAR(100);
 DECLARE jbt VARCHAR(100);
 SELECT nama_pegawai, jabatan INTO nm_peg, jbt FROM tbl_pegawai WHERE id_pegawai = old.id_admin;
 INSERT INTO tbl_log(id_pegawai, nama_pegawai, jabatan, aksi) VALUES (old.id_pegawai, nm_peg, jbt, CONCAT('Login : menghapus username ', old.username));
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `tLoginTambah` AFTER INSERT ON `tbl_login` FOR EACH ROW BEGIN
 DECLARE nm_peg VARCHAR(100);
 DECLARE jbt VARCHAR(100);
 SELECT nama_pegawai, jabatan INTO nm_peg, jbt FROM tbl_pegawai WHERE id_pegawai = new.id_admin;
 INSERT INTO tbl_log(id_pegawai, nama_pegawai, jabatan, aksi) VALUES (new.id_admin, nm_peg, jbt, CONCAT('Login : menambahkan username : ', new.username));
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `tLoginUpdate` BEFORE UPDATE ON `tbl_login` FOR EACH ROW BEGIN
 DECLARE nm_peg VARCHAR(100);
 DECLARE jbt VARCHAR(100);
 SELECT nama_pegawai, jabatan INTO nm_peg, jbt FROM tbl_pegawai WHERE id_pegawai = old.id_admin;
 INSERT INTO tbl_log(id_pegawai, nama_pegawai, jabatan, aksi) VALUES (old.id_admin, nm_peg, jbt, CONCAT('Login : merubah username : ', old.username, ' menjadi ', new.username));
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_meja`
--

CREATE TABLE `tbl_meja` (
  `id_meja` int(11) NOT NULL,
  `nomor_meja` varchar(255) NOT NULL,
  `status_meja` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tbl_meja`
--

INSERT INTO `tbl_meja` (`id_meja`, `nomor_meja`, `status_meja`) VALUES
(1, '4', 'Occupied'),
(7, '2', 'Available'),
(10, '3', 'Occupied');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_menu`
--

CREATE TABLE `tbl_menu` (
  `id_menu` int(11) NOT NULL,
  `nama_menu` varchar(150) NOT NULL,
  `id_jenis_menu` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `img` varchar(150) NOT NULL,
  `id_pegawai` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tbl_menu`
--

INSERT INTO `tbl_menu` (`id_menu`, `nama_menu`, `id_jenis_menu`, `harga`, `img`, `id_pegawai`) VALUES
(46, 'Nasi Liwet', 40, 30000, '27042022183918nasi liwet2-min.jpg', 2),
(47, 'Telor Dadar', 40, 3500, '27042022184012telur dadar1-min.jpg', 1),
(48, 'Es Jeruk', 41, 10000, '27042022184031es jeruk-min.jpg', 1),
(49, 'Es Campur', 41, 15000, '27042022184055Es-Campur1-min.jpg', 1);

--
-- Trigger `tbl_menu`
--
DELIMITER $$
CREATE TRIGGER `tMenuDelete` BEFORE DELETE ON `tbl_menu` FOR EACH ROW BEGIN
 DECLARE nm_peg VARCHAR(100);
 DECLARE jbt VARCHAR(100);
 SELECT nama_pegawai, jabatan INTO nm_peg, jbt FROM tbl_pegawai WHERE id_pegawai = old.id_pegawai;
 INSERT INTO tbl_log(id_pegawai, nama_pegawai, jabatan, aksi) VALUES (old.id_pegawai, nm_peg, jbt, CONCAT('Nama menu - Menghapus nama menu : ', old.nama_menu ));
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `tMenuTambah` AFTER INSERT ON `tbl_menu` FOR EACH ROW BEGIN
 DECLARE nm_peg VARCHAR(100);
 DECLARE jbt VARCHAR(100);
 DECLARE jm VARCHAR(100);
 SELECT nama_pegawai, jabatan INTO nm_peg, jbt FROM tbl_pegawai WHERE id_pegawai = new.id_pegawai;
 SELECT jenis_menu INTO jm FROM tbl_jenis_menu WHERE id_jenis_menu = new.id_jenis_menu;
 INSERT INTO tbl_log(id_pegawai, nama_pegawai, jabatan, aksi) VALUES (new.id_pegawai, nm_peg, jbt, CONCAT('Nama menu - menanbah nama menu : ', new.nama_menu, ', jenis menu : ', jm, ' dan harga : Rp. ', new.harga));
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `tMenuUpdate` BEFORE UPDATE ON `tbl_menu` FOR EACH ROW BEGIN
 DECLARE nm_peg VARCHAR(100);
 DECLARE jbt VARCHAR(100);
 DECLARE jm VARCHAR(100);
 DECLARE jm1 VARCHAR(100);
 SELECT nama_pegawai, jabatan INTO nm_peg, jbt FROM tbl_pegawai WHERE id_pegawai = old.id_pegawai;
 SELECT jenis_menu INTO jm FROM tbl_jenis_menu WHERE id_jenis_menu = new.id_jenis_menu;
  SELECT jenis_menu INTO jm1 FROM tbl_jenis_menu WHERE id_jenis_menu = old.id_jenis_menu;
 INSERT INTO tbl_log(id_pegawai, nama_pegawai, jabatan, aksi) VALUES (old.id_pegawai, nm_peg, jbt, CONCAT('Nama menu - mengubah nama menu : ', old.nama_menu, ' menjadi ', new.nama_menu, ', jenis menu : ', jm1, ' menjadi ', jm, ' dan harga dari Rp. ', old.harga, ' menjadi Rp. ', new.harga));
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_pegawai`
--

CREATE TABLE `tbl_pegawai` (
  `id_pegawai` int(11) NOT NULL,
  `nama_pegawai` varchar(100) NOT NULL,
  `jenis_kelamin` enum('Laki-laki','Perempuan') NOT NULL,
  `alamat` text NOT NULL,
  `telp` varchar(100) NOT NULL,
  `jabatan` enum('Kasir','Manajer','Admin','Waiter') NOT NULL,
  `photo` varchar(150) DEFAULT NULL,
  `id_admin` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tbl_pegawai`
--

INSERT INTO `tbl_pegawai` (`id_pegawai`, `nama_pegawai`, `jenis_kelamin`, `alamat`, `telp`, `jabatan`, `photo`, `id_admin`) VALUES
(1, 'Haikal', 'Perempuan', 'Jl. Jakarta', '081', 'Manajer', NULL, 1),
(2, 'Aji', 'Laki-laki', 'Jl. Subang', '081', 'Admin', NULL, 1),
(10, 'Frieren', 'Perempuan', 'MERICAAAAAAAAAAAAAAAAAAAAAAAAAAA', '021', 'Waiter', NULL, 10),
(17, 'Siswa', 'Perempuan', 'Jl. Banda No. 1', '081', 'Kasir', '', 1),
(18, 'Vino', 'Laki-laki', 'Jl. Sunda No. 1', '081234', 'Kasir', '', 1);

--
-- Trigger `tbl_pegawai`
--
DELIMITER $$
CREATE TRIGGER `tPegawaiHapus` BEFORE DELETE ON `tbl_pegawai` FOR EACH ROW BEGIN
 DECLARE nm_peg VARCHAR(100);
 DECLARE jbt VARCHAR(100);
 SELECT nama_pegawai, jabatan INTO nm_peg, jbt FROM tbl_pegawai WHERE id_pegawai = old.id_admin;
 INSERT INTO tbl_log(id_pegawai, nama_pegawai, jabatan, aksi) VALUES (old.id_pegawai, nm_peg, jbt, CONCAT('Pegawai - Menghapus nama pegawai : ', old.nama_pegawai ));
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `tPegawaiTambah` AFTER INSERT ON `tbl_pegawai` FOR EACH ROW BEGIN
 DECLARE nm_peg VARCHAR(100);
 DECLARE jbt VARCHAR(100);
 SELECT nama_pegawai, jabatan INTO nm_peg, jbt FROM tbl_pegawai WHERE id_pegawai = new.id_admin;
 INSERT INTO tbl_log(id_pegawai, nama_pegawai, jabatan, aksi) VALUES (new.id_pegawai, nm_peg, jbt, CONCAT('Pegawai - menanbah nama pegawai : ', new.nama_pegawai, ' dan jabatan sebagai ', new.jabatan));
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `tPegawaiUpdate` BEFORE UPDATE ON `tbl_pegawai` FOR EACH ROW BEGIN
 DECLARE nm_peg VARCHAR(100);
 DECLARE jbt VARCHAR(100);
 SELECT nama_pegawai, jabatan INTO nm_peg, jbt FROM tbl_pegawai WHERE id_pegawai = old.id_admin;
 INSERT INTO tbl_log(id_pegawai, nama_pegawai, jabatan, aksi) VALUES (old.id_pegawai, nm_peg, jbt, CONCAT('Pegawai - Mengubah nama pegawai : ', old.nama_pegawai, ' menjadi ', new.nama_pegawai, ', jenis kelamin : ', old.jenis_kelamin, ' menjadi ', new.jenis_kelamin,', alamat : ', old.alamat, ' menjadi ', new.alamat, ', telp : ', old.telp, ' menjadi ', new.telp ));
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_transaksi`
--

CREATE TABLE `tbl_transaksi` (
  `id_transaksi` int(11) NOT NULL,
  `tgl_transaksi` date NOT NULL,
  `no_transaksi` varchar(100) NOT NULL,
  `total_transaksi` int(11) NOT NULL,
  `no_meja` int(11) NOT NULL,
  `total_bayar` int(11) NOT NULL,
  `id_pegawai` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tbl_transaksi`
--

INSERT INTO `tbl_transaksi` (`id_transaksi`, `tgl_transaksi`, `no_transaksi`, `total_transaksi`, `no_meja`, `total_bayar`, `id_pegawai`) VALUES
(226, '2024-03-25', '20240325000000226', 10000, 1, 20000, 18);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_transaksi_detail`
--

CREATE TABLE `tbl_transaksi_detail` (
  `id_detail` int(11) NOT NULL,
  `no_transaksi` varchar(100) NOT NULL,
  `id_menu` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `id_pegawai` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `tbl_transaksi_detail`
--

INSERT INTO `tbl_transaksi_detail` (`id_detail`, `no_transaksi`, `id_menu`, `qty`, `harga`, `id_pegawai`) VALUES
(306, '20240325000000226', 48, 1, 10000, 18);

--
-- Trigger `tbl_transaksi_detail`
--
DELIMITER $$
CREATE TRIGGER `tTransaksiTambah` AFTER INSERT ON `tbl_transaksi_detail` FOR EACH ROW BEGIN
 DECLARE nm_peg VARCHAR(100);
 DECLARE jbt VARCHAR(100);
 DECLARE nmMenu VARCHAR(100);
 SELECT nama_pegawai, jabatan INTO nm_peg, jbt FROM tbl_pegawai WHERE id_pegawai = new.id_pegawai;
 SELECT nama_menu INTO nmMenu FROM tbl_menu WHERE id_menu = new.id_menu;
 INSERT INTO tbl_log(id_pegawai, nama_pegawai, jabatan, aksi) VALUES (new.id_pegawai, nm_peg, jbt, CONCAT('Transaksi detail - menjual ', nmMenu, ' sebanyak ', new.qty, ' dengan harga Rp. ', new.harga));
END
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `tbl_jenis_menu`
--
ALTER TABLE `tbl_jenis_menu`
  ADD PRIMARY KEY (`id_jenis_menu`),
  ADD UNIQUE KEY `jenis_menu` (`jenis_menu`),
  ADD KEY `id_pegawai` (`id_pegawai`);

--
-- Indeks untuk tabel `tbl_log`
--
ALTER TABLE `tbl_log`
  ADD PRIMARY KEY (`id_log`),
  ADD KEY `id_pegawai` (`id_pegawai`);

--
-- Indeks untuk tabel `tbl_login`
--
ALTER TABLE `tbl_login`
  ADD PRIMARY KEY (`id_login`),
  ADD UNIQUE KEY `username` (`username`),
  ADD KEY `id_pegawai` (`id_pegawai`);

--
-- Indeks untuk tabel `tbl_meja`
--
ALTER TABLE `tbl_meja`
  ADD PRIMARY KEY (`id_meja`);

--
-- Indeks untuk tabel `tbl_menu`
--
ALTER TABLE `tbl_menu`
  ADD PRIMARY KEY (`id_menu`),
  ADD KEY `id_jenis_menu_2` (`id_jenis_menu`),
  ADD KEY `id_pegawai` (`id_pegawai`);

--
-- Indeks untuk tabel `tbl_pegawai`
--
ALTER TABLE `tbl_pegawai`
  ADD PRIMARY KEY (`id_pegawai`);

--
-- Indeks untuk tabel `tbl_transaksi`
--
ALTER TABLE `tbl_transaksi`
  ADD PRIMARY KEY (`id_transaksi`),
  ADD UNIQUE KEY `no_transaksi` (`no_transaksi`),
  ADD KEY `id_pegawai` (`id_pegawai`);

--
-- Indeks untuk tabel `tbl_transaksi_detail`
--
ALTER TABLE `tbl_transaksi_detail`
  ADD PRIMARY KEY (`id_detail`),
  ADD KEY `no_transaksi` (`no_transaksi`),
  ADD KEY `id_menu` (`id_menu`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `tbl_jenis_menu`
--
ALTER TABLE `tbl_jenis_menu`
  MODIFY `id_jenis_menu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT untuk tabel `tbl_log`
--
ALTER TABLE `tbl_log`
  MODIFY `id_log` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=670;

--
-- AUTO_INCREMENT untuk tabel `tbl_login`
--
ALTER TABLE `tbl_login`
  MODIFY `id_login` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=116;

--
-- AUTO_INCREMENT untuk tabel `tbl_meja`
--
ALTER TABLE `tbl_meja`
  MODIFY `id_meja` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `tbl_menu`
--
ALTER TABLE `tbl_menu`
  MODIFY `id_menu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT untuk tabel `tbl_pegawai`
--
ALTER TABLE `tbl_pegawai`
  MODIFY `id_pegawai` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT untuk tabel `tbl_transaksi`
--
ALTER TABLE `tbl_transaksi`
  MODIFY `id_transaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=227;

--
-- AUTO_INCREMENT untuk tabel `tbl_transaksi_detail`
--
ALTER TABLE `tbl_transaksi_detail`
  MODIFY `id_detail` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=307;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `tbl_transaksi_detail`
--
ALTER TABLE `tbl_transaksi_detail`
  ADD CONSTRAINT `tbl_transaksi_detail_ibfk_2` FOREIGN KEY (`no_transaksi`) REFERENCES `tbl_transaksi` (`no_transaksi`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
