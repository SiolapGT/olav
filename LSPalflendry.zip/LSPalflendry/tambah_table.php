<?php
 $judul = 'TAMBAH MEJA';
 include "header.php";
 include "sidebar.php";
 include "topbar.php"; ?>
<div class="card">
	<div class="card-header">
		<a href="dashboard.php" class="btn btn-success btn-icon-split">
       		 <span class="icon text-white-50">
            	 <i class="fas fa-arrow-left"></i>
             </span>
             <span class="text">Kembali</span>
        </a>
	</div>
	<div class="card-body">
		<form method="post" action="simpan_table.php">
			<div class="form-group">
				<label>Nomer Meja</label>
				<input name="nomor_meja" class="form-control" type="text" placeholder=" " required>
			</div>
			<div class="form-group">
				<label>Status Meja</label>
				<select name="status_meja" class="form-select" aria-label="Default select example"> 
					<option selected hidden>  </option>	
					<option value="Available">Available</option>
					<option value="Occupied">Occupied</option>
				</select>
			</div>
			<div class="form-group">
				<button type="submit" class="btn btn-success"><i class="fa fa-save"></i>SIMPAN</button>
				<button type="reset" class="btn btn-danger"><i class="fa fa-trash"></i>KOSONGKAN</button>
			</div>
		</form>
	</div>
</div>
<?php include('footer.php') ?>