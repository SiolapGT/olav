<?php 

$id_meja = $_GET['id_meja'];

include'koneksi.php';
$sql = "DELETE FROM tbl_meja WHERE id_meja='$id_meja'";
$query = mysqli_query($koneksi, $sql);

if($query){ ?>
        <script>
            alert("Data table Sudah Terhapus.");
            window.location.assign("entri-meja.php");
        </script>
<?php 
 
}else{ ?>
        <script>
            alert("Data table Tidak Terhapus.");
            window.location.assign("entri-meja.php");
        </script>
<?php 

}   