<?php 

$id_meja = $_POST['id_meja'];
$nomor_meja	= $_POST['nomor_meja'];
$status_meja = $_POST['status_meja'];

include'koneksi.php';
$sql = "UPDATE tbl_meja SET nomor_meja='$nomor_meja',status_meja='$status_meja' WHERE id_meja='$id_meja'";
$query = mysqli_query($koneksi, $sql);

if($query){ ?>
		<script>
			alert("Data table Sudah Teredit.");
			window.location.assign("entri-meja.php");
		</script>
<?php 
 
}else{ ?>
		<script>
			alert("Data table Tidak Teredit.");
			window.location.assign("entri-meja.php");
		</script>
<?php

}