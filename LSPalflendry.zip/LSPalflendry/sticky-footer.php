</div>

<footer style="height: 42px; background: Burlywood;">
	<div class="container">
		<div class="copyright text-center pt-2" style="color: black; font-weight: bold">
			<span>Copyright &copy; ALFLENDRY XII RPL2 <?= date('Y');  ?></span>
		</div>
	</div>
</footer>

</div>
</div>

<a class="scroll-to-top rounded" href="#page-top">
	<i class="fas fa-angle-up"></i>
</a>